Hướng dẫn vận hành hệ thống QC5.6 - Đầy đủ chi tiết từng bước.
