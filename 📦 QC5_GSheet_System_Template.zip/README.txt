# QC5 Google Sheet Integration System

- Đây là bộ template CSV cho 13 module quản lý
- Tệp `folder_structure.txt` mô phỏng cây thư mục hệ thống
- Tích hợp với Google Sheet thông qua `IMPORTRANGE`, `QUERY`
