export const translations = {
  en: {
    nav: {
      dashboard: "Dashboard",
      customers: "Customer Forms",
      hr: "HR Management",
      financial: "Financial",
      reports: "Reports",
      data: "Data Lookup",
      settings: "Settings"
    },
    dashboard: {
      title: "Dashboard Overview",
      subtitle: "Monitor your business operations and key metrics",
      stats: {
        customers: "Total Customers",
        revenue: "Monthly Revenue",
        forms: "Active Forms",
        health: "System Health",
        submissions: "submissions"
      },
      quickActions: {
        title: "Quick Actions",
        newCustomerForm: "New Customer Form",
        newCustomerFormDesc: "Create customer data collection form",
        hrManagement: "HR Management",
        hrManagementDesc: "Employee data and processes",
        financialForms: "Financial Forms",
        financialFormsDesc: "Transaction and payment tracking"
      },
      recentActivity: {
        title: "Recent Activity",
        fromDate: "From",
        toDate: "To"
      },
      systemStatus: {
        title: "System Status",
        operational: "Operational",
        slow: "Slow",
        lastBackup: "Last:"
      },
      quickNavigation: {
        title: "Quick Navigation",
        qrGenerator: "QR Code Generator",
        dataLookup: "Data Lookup",
        exportData: "Export Data",
        backupSystem: "Backup System"
      },
      quickSearch: {
        title: "Quick Search",
        placeholder: "Search customers, transactions...",
        allCategories: "All Categories",
        searchButton: "Search"
      }
    },
    forms: {
      createNew: "Create New Form",
      formType: "Form Type",
      formName: "Form Name",
      description: "Description",
      formFields: "Form Fields",
      addCustomField: "Add Custom Field",
      generateQR: "Generate QR Code",
      enableValidation: "Enable 6-level validation",
      cancel: "Cancel",
      create: "Create Form",
      customerInfo: "Customer Information",
      hrManagement: "HR Management",
      financialTransaction: "Financial Transaction"
    },
    common: {
      loading: "Loading...",
      error: "Error",
      success: "Success",
      save: "Save",
      delete: "Delete",
      edit: "Edit",
      view: "View",
      close: "Close",
      search: "Search",
      filter: "Filter",
      export: "Export",
      import: "Import"
    }
  },
  vi: {
    nav: {
      dashboard: "Tổng quan",
      customers: "Biểu mẫu khách hàng",
      hr: "Quản lý nhân sự",
      financial: "Tài chính",
      reports: "Báo cáo",
      data: "Tra cứu dữ liệu",
      settings: "Cài đặt"
    },
    dashboard: {
      title: "Tổng quan hệ thống",
      subtitle: "Theo dõi hoạt động kinh doanh và các chỉ số quan trọng",
      stats: {
        customers: "Tổng khách hàng",
        revenue: "Doanh thu tháng",
        forms: "Biểu mẫu hoạt động",
        health: "Tình trạng hệ thống",
        submissions: "lượt gửi"
      },
      quickActions: {
        title: "Thao tác nhanh",
        newCustomerForm: "Biểu mẫu khách hàng mới",
        newCustomerFormDesc: "Tạo biểu mẫu thu thập dữ liệu khách hàng",
        hrManagement: "Quản lý nhân sự",
        hrManagementDesc: "Dữ liệu và quy trình nhân viên",
        financialForms: "Biểu mẫu tài chính",
        financialFormsDesc: "Theo dõi giao dịch và thanh toán"
      },
      recentActivity: {
        title: "Hoạt động gần đây",
        fromDate: "Từ ngày",
        toDate: "Đến ngày"
      },
      systemStatus: {
        title: "Trạng thái hệ thống",
        operational: "Hoạt động",
        slow: "Chậm",
        lastBackup: "Lần cuối:"
      },
      quickNavigation: {
        title: "Điều hướng nhanh",
        qrGenerator: "Tạo mã QR",
        dataLookup: "Tra cứu dữ liệu",
        exportData: "Xuất dữ liệu",
        backupSystem: "Hệ thống sao lưu"
      },
      quickSearch: {
        title: "Tìm kiếm nhanh",
        placeholder: "Tìm khách hàng, giao dịch...",
        allCategories: "Tất cả danh mục",
        searchButton: "Tìm kiếm"
      }
    },
    forms: {
      createNew: "Tạo biểu mẫu mới",
      formType: "Loại biểu mẫu",
      formName: "Tên biểu mẫu",
      description: "Mô tả",
      formFields: "Trường biểu mẫu",
      addCustomField: "Thêm trường tùy chỉnh",
      generateQR: "Tạo mã QR",
      enableValidation: "Bật xác thực 6 cấp",
      cancel: "Hủy",
      create: "Tạo biểu mẫu",
      customerInfo: "Thông tin khách hàng",
      hrManagement: "Quản lý nhân sự",
      financialTransaction: "Giao dịch tài chính"
    },
    common: {
      loading: "Đang tải...",
      error: "Lỗi",
      success: "Thành công",
      save: "Lưu",
      delete: "Xóa",
      edit: "Sửa",
      view: "Xem",
      close: "Đóng",
      search: "Tìm kiếm",
      filter: "Lọc",
      export: "Xuất",
      import: "Nhập"
    }
  }
};

export type Language = keyof typeof translations;
export type TranslationKey = keyof typeof translations.en;
