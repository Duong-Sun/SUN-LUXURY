# Role & Module ID Convention

## Role IDs:
- Admin: ROLE_ADMIN
- Manager: ROLE_MANAGER
- Viewer: ROLE_VIEWER
- Bot: ROLE_BOT

## Module Codes:
- HRM: Human Resource Management
- FIN: Finance & Accounting
- PRJ: Project Management
- DWH: Data Warehouse

