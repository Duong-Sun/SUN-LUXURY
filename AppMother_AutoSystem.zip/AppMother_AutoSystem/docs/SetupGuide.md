# Setup Guide

1. Clone repository
2. Install dependencies: npm install
3. Configure Firebase
4. Start project: npm run dev

System auto-generates modules based on config/roles.json and departments.json
