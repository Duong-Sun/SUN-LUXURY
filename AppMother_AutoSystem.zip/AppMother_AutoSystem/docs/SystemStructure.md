# System Architecture

## Layers
- Frontend: React + Tailwind
- Backend: Firebase Auth + Firestore
- State: Context API
- API Routing: /api/routes

## Modules:
- HumanResources
- Finance
- ProjectManagement
- DataWarehouse
