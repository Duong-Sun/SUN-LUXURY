
from datetime import datetime

def generate_id(prefix, dept_code, seq):
    today = datetime.today()
    return f"{prefix}.{today.year}.{today.month:02d}.{dept_code}.{seq:04d}"
