
def auto_route(entry):
    if entry['type'] == 'KHACHHANG':
        return ['CRM', 'CSKH', 'LETAN']
    if entry['type'] == 'PHIEUTHU':
        return ['TAICHINH', 'CRM']
    return []
