
# QC5 Smart Input System

- 16 Phân hệ liên kết theo mã QR
- Google Forms hoặc Web App nhận input
- Tự động sinh mã ID cho mỗi đối tượng
- Routing theo loại biểu mẫu (entry type)
- Thông báo & cập nhật dữ liệu các phân hệ liên quan

Example: KHACHHANG form routes to CRM + CSKH + LETAN
